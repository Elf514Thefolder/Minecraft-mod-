
package net.mcreator.mymod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;

import net.mcreator.mymod.itemgroup.ModItemGroup;
import net.mcreator.mymod.MyModModElements;

import java.util.List;

@MyModModElements.ModElement.Tag
public class WiiItem extends MyModModElements.ModElement {
	@ObjectHolder("my_mod:wii")
	public static final Item block = null;
	public WiiItem(MyModModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, MyModModElements.sounds.get(new ResourceLocation("my_mod:wii")),
					new Item.Properties().group(ModItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("wii");
		}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
			list.add(new StringTextComponent("Wii sports"));
		}
	}
}
